// main.js

function init() {
    var scene = new THREE.Scene();
    scene.background = new THREE.Color(0xeeeeee); // Chuyển màu nền ra đây

    // --- BẮT ĐẦU: Tải Texture ---
    // Để chạy được, bạn cần mở file HTML thông qua một server cục bộ (ví dụ: Live Server trong VS Code)
    // do chính sách bảo mật của trình duyệt khi tải file từ máy.
    const textureLoader = new THREE.TextureLoader();
    const planeTexture = textureLoader.load('textures/grid.png'); // Thay bằng file texture sàn của bạn
    const boxTexture = textureLoader.load('textures/crate.gif');   // Thay bằng file texture hộp của bạn

    // --- KẾT THÚC: Tải Texture ---


    // --- BẮT ĐẦU: Thêm Ánh sáng ---
    const ambientLight = new THREE.AmbientLight(0xffffff,50); // Ánh sáng môi trường, làm các mặt tối không bị đen hoàn toàn
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 30); // Ánh sáng định hướng (như mặt trời)
    directionalLight.position.set(5, 10, 7.5); // Vị trí của nguồn sáng
    directionalLight.castShadow = true; // Cho phép đèn này tạo bóng đổ

    // Cấu hình chất lượng bóng đổ
    directionalLight.shadow.mapSize.width = 1024;
    directionalLight.shadow.mapSize.height = 1024;

    scene.add(directionalLight);
    // --- KẾT THÚC: Thêm Ánh sáng ---


    // --- Cập nhật các đối tượng để sử dụng vật liệu mới và texture ---
    var box = getBox(1, 1, 1, boxTexture); // w, h, d. Dùng height = 1 cho cân đối
    var plane = getPlane(10, planeTexture);
    var dodecahedron = getDodecahedronGeometry(0.5);
    var octahedron = getOctahedron(0.5);

    // Bật/tắt khả năng tạo và nhận bóng đổ cho các đối tượng
    box.castShadow = true;
    dodecahedron.castShadow = true;
    octahedron.castShadow = true;
    plane.receiveShadow = true; // Sàn nhà nhận bóng đổ

    // Initial positions
    box.position.y = 0.5; // Cập nhật vị trí Y của hộp
    dodecahedron.position.set(-2, 0.5, 0);
    octahedron.position.set(2, 0.5, 0);
    plane.rotation.x = -Math.PI / 2;

    scene.add(box);
    scene.add(plane);
    scene.add(dodecahedron);
    scene.add(octahedron);

    var camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 1, 1000);
    camera.position.set(6, 4, 6);
    camera.lookAt(new THREE.Vector3(0, 0, 0));

    var renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);

    // --- BẮT ĐẦU: Kích hoạt Shadow Map ---
    renderer.shadowMap.enabled = true; // Quan trọng!
    renderer.shadowMap.type = THREE.PCFSoftShadowMap; // Tạo bóng đổ mềm hơn
    // --- KẾT THÚC: Kích hoạt Shadow Map ---

    document.getElementById("webgl").appendChild(renderer.domElement);

    var angle = 0;
    var clock = new THREE.Clock();

    function animate() {
        requestAnimationFrame(animate);

        var delta = clock.getDelta();
        angle += 0.5 * delta;

        // 1. Phép quay (Rotation) - Quay khối hộp quanh trục Y của nó
        box.rotation.y += 0.01;

        // 2. Phép tỉ lệ (Scaling) - Làm cho khối Dodecahedron phình to thu nhỏ
        var scaleFactor = 1 + 0.25 * Math.sin(angle * 2.5);
        dodecahedron.scale.set(scaleFactor, scaleFactor, scaleFactor);

        // 3. Phép tịnh tiến (Translation) - Làm cho khối Octahedron di chuyển lên xuống
        octahedron.position.y = 0.5 + 0.5 * Math.sin(angle * 2);

        // Camera sẽ quay quanh điểm gốc (0,0,0)
        camera.position.x = 6 * Math.cos(angle);
        camera.position.z = 6 * Math.sin(angle);

        // Camera sẽ nhìn vào vị trí của khối hộp
        camera.lookAt(box.position);

        renderer.render(scene, camera);
    }

    animate();

    // Handle window resize
    window.addEventListener('resize', onWindowResize, false);
    function onWindowResize() {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    }
}

// --- Cập nhật các hàm tạo đối tượng ---

// Thêm tham số `texture` và sử dụng MeshStandardMaterial
function getBox(w, h, d, texture) {
    var geometry = new THREE.BoxGeometry(w, h, d);
    var material = new THREE.MeshStandardMaterial({
        color: 0xffffff, // Màu trắng để texture hiển thị đúng màu
        map: texture     // Áp dụng texture
    });
    return new THREE.Mesh(geometry, material);
}

// Thêm tham số `texture` và sử dụng MeshStandardMaterial
function getPlane(size, texture) {
    var geometry = new THREE.PlaneGeometry(size, size);
    var material = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        map: texture,
        side: THREE.DoubleSide
    });
    // Lặp lại texture nếu kích thước plane lớn
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(4, 4); // Lặp lại texture 4x4 lần

    return new THREE.Mesh(geometry, material);
}

// Sử dụng MeshStandardMaterial để phản ứng với ánh sáng
function getDodecahedronGeometry(radius) {
    var geometry = new THREE.DodecahedronGeometry(radius);
    var material = new THREE.MeshStandardMaterial({
        color: 0xff0000, // Màu đỏ
        roughness: 0.5,  // Điều chỉnh độ nhám bề mặt
        metalness: 0.1   // Điều chỉnh độ kim loại
    });
    return new THREE.Mesh(geometry, material);
}

// Sử dụng MeshStandardMaterial để phản ứng với ánh sáng
function getOctahedron(radius) {
    const geometry = new THREE.OctahedronGeometry(radius);
    const material = new THREE.MeshStandardMaterial({
        color: 0x0b03fc, // Màu xanh dương
        roughness: 0.2,
        metalness: 0.8
    });
    return new THREE.Mesh(geometry, material);
}

// Hàm này không còn được sử dụng trong bản cập nhật, nhưng vẫn giữ lại để tham khảo
function getCylinder(radiusTop, radiusBottom, height) {
    var geometry = new THREE.CylinderGeometry(radiusTop, radiusBottom, height, 32);
    var material = new THREE.MeshStandardMaterial({ color: 0x0000ff });
    return new THREE.Mesh(geometry, material);
}

init();